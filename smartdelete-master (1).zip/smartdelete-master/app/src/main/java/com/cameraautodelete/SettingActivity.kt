package com.cameraautodelete

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import kotlinx.android.synthetic.main.activity_setting.*
import kotlinx.android.synthetic.main.common_toolbar.*
import android.R.string.cancel
import android.app.Activity
import android.app.PendingIntent
import android.content.Intent
import android.content.Context.ALARM_SERVICE
import androidx.core.content.ContextCompat.getSystemService
import android.app.AlarmManager
import android.util.Log


class SettingActivity : BaseActivity() {


    val deleteTimeList = arrayOf("Select Time", "1 Min", "5 Min", "10 Min", "15 Min", "20 Min", "25 Min", "1 Hour", "2 Hours", "4 Hours", "6 Hours", "12 Hours", "1 Day", "2 Days", "3 Days", "4 Days", "5 Days", "6 Days", "1 Week")
    val deleteTimeMillisList = arrayOf("0","60000", "300000","600000", "900000", "1200000", "1500000", "3600000", "7200000", "14400000", "21600000", "43200000", "86400000","172800000","259200000","345600000","432000000","518400000","604800000")

    var isautodelete:Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setting)

        image_back_arrow.setOnClickListener {
            finish()
        }
        toolbar_title.text = "Setting"
        text_setting.visibility = View.GONE

        val arrayAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, deleteTimeList)
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spiner_delete_time.adapter = arrayAdapter

        spiner_delete_time.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                PreferenceUtils?.getInstance(this@SettingActivity).setValue("deleteTimeSelect", deleteTimeList?.get(position))
                PreferenceUtils?.getInstance(this@SettingActivity)?.setValue("deleteTime", deleteTimeMillisList?.get(position))

            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                TODO("not implemented")
            }
        }

        var selectedPos = getDeletePos()
        spiner_delete_time?.setSelection(selectedPos)
        var isAutodelete = PreferenceUtils?.getInstance(this@SettingActivity)?.setValue("autodelete", "true")
        if(isAutodelete?.equals("true")){
            chkbox_autodelete.isChecked = true
            isautodelete = true
        }else{
            chkbox_autodelete.isChecked = false
            isautodelete = false
        }
        if(intent?.hasExtra("autodeleteflag")!!){
            isautodelete = intent?.getBooleanExtra("autodeleteflag", false)!!;
        }

         if(isautodelete){
            chkbox_autodelete.isChecked = true
            isautodelete = true
        }else{
            chkbox_autodelete.isChecked = false
            isautodelete = false
        }

        chkbox_autodelete.setOnCheckedChangeListener { compoundButton, boolean ->
            if(boolean){
                isautodelete = true
                rl_spinner.visibility = View.VISIBLE
                PreferenceUtils?.getInstance(this@SettingActivity)?.setValue("autodelete", "true")
            }else{
                isautodelete = false
                rl_spinner.visibility = View.GONE
                PreferenceUtils?.getInstance(this@SettingActivity)?.setValue("autodelete", "false")
            }
            var autodelete = PreferenceUtils.getInstance(this).getValue("autodelete")
            Log.e("AUTODELETE", autodelete)
        }

        text_submit.setOnClickListener {
            var intent:Intent = Intent()
            intent.putExtra("isautodelete", isautodelete)
            setResult(Activity.RESULT_OK, intent)
            finish()
        }

    }


    fun getDeletePos():Int{
        deleteTimeList?.forEachIndexed { pos, obj ->
            if (obj?.equals(PreferenceUtils?.getInstance(this@SettingActivity)?.getValue("deleteTimeSelect"))) {
                return pos
            }
        }
        return 0
    }

}
