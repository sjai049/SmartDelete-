package com.cameraautodelete;

class MessageEvent2 {

    String imgPath;

    MessageEvent2(String imgPath){
        this.imgPath = imgPath;
    }
}
