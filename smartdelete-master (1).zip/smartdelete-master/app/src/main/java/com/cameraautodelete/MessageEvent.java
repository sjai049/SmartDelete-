package com.cameraautodelete;

class MessageEvent {
}
